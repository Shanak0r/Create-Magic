
const CrystalColors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet', 'white', 'black']
const quark_color = [['pink', 'pink'], ['red', 'red'], ['orange', 'orange'], ['yellow', 'yellow'], ['cyan', 'blue'] , ['purple', 'lavender']]
	
onEvent('recipes', event => {

	for (let i = 0; i < CrystalColors.length; i++){
		event.recipes.createPressing(['quark:'+CrystalColors[i]+'_corundum_pane'], [
		'quark:'+CrystalColors[i]+'_corundum_cluster'])
	}//end loop
	
	event.recipes.createCompacting('quark:permafrost', [
		'minecraft:packed_ice'])
		
	for (let i in quark_color){
		event.recipes.createDeploying('quark:' + quark_color[i][1] + '_blossom_sapling', [
					'quark:' + quark_color[i][0] + '_rune', '#quark:blossom_saplings'])
	}//end loop
	
	
})

onEvent('item.tags', event => {
	for (let i = 0; i < CrystalColors.length; i++){
		event.add('quark:corundum_clusters', 'quark:'+CrystalColors[i]+'_corundum_cluster')
	}
	event.add('quark:blossom_saplings', [
	'quark:yellow_blossom_sapling',
	'quark:orange_blossom_sapling',
	'quark:red_blossom_sapling',
	'quark:pink_blossom_sapling',
	'quark:lavender_blossom_sapling',
	'quark:blue_blossom_sapling'
	])
})