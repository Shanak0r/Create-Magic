const coral_colors = ['tube', 'brain', 'bubble', 'fire', 'horn']
onEvent('recipes', event => {
	
	{//removals
	
	}
	
	{//minecraft
		//removals
		event.remove({id: 'minecraft:beacon'})
		event.remove({id: 'minecraft:end_crystal'})
		
		//saddle
		event.shaped('minecraft:saddle', [
			'LLL',
			'I I'
		], {
			L: 'minecraft:leather',
			I: 'byg:chain_plating'
		})
		//Coral
		for(let c in coral_colors){
			event.shapeless('minecraft:' + coral_colors[c] + '_coral_block', ['4x #forge:' + coral_colors[c] + '_corals'])
			event.shapeless('minecraft:dead_' + coral_colors[c] + '_coral_block', ['4x #forge:dead_' + coral_colors[c] + '_corals'])
		}//end for loop
		event.shapeless('byg:warped_coral_block', ['4x #forge:warped_corals'])
		
		//Beacon
		event.recipes.createMechanicalCrafting('minecraft:beacon', [
			'GGGGG',
			'GXXXG',
			'GXNXG',
			'GEPEG',
			'OOOOO'
		], {
			G: 'minecraft:glass',
			O: 'minecraft:obsidian',
			N: 'minecraft:nether_star',
			X: 'create:experience_nugget',
			E: 'create:electron_tube',
			P: 'create:precision_mechanism'
		})
		//End Crystal
		event.recipes.createMechanicalCrafting('minecraft:end_crystal', [
			'GGGGG',
			'GXXXG',
			'GXLXG',
			'GXXXG',
			'GGGGG'
		], {
			G: 'minecraft:glass',
			X: 'create:experience_nugget',
			L: 'phantasm:fallen_star'
		})
	}
	
	{//Create
		{//removals
		event.remove({id: 'create:crafting/materials/electron_tube'})
		event.remove({id: 'create:crafting/kinetics/mechanical_crafter'})
		event.remove({id: 'create:crafting/kinetics/rotation_speed_controller'})
		event.remove({id: 'create:crafting/kinetics/sequenced_gearshift'})
		}
		
		{//Deploy
		event.recipes.createDeploying('create:electron_tube', ['create:iron_sheet', 'create:polished_rose_quartz'])
		}
		
		{//Sequenced Assembly
		let transitional = 'create:incomplete_precision_mechanism'
		//Mech Crafter
		event.recipes.createSequencedAssembly(['3x create:mechanical_crafter',
		], 'create:brass_casing', [
			event.recipes.createDeploying(transitional, [transitional, 'minecraft:crafting_table']),
			event.recipes.createDeploying(transitional, [transitional, 'create:cogwheel']),
			event.recipes.createDeploying(transitional, [transitional, 'create:electron_tube'])
		]).loops(3).transitionalItem('create:brass_casing')
		//Rotation Speed Controller
		event.recipes.createSequencedAssembly(['create:rotation_speed_controller',
		], 'create:brass_casing', [
			event.recipes.createDeploying(transitional, [transitional, 'create:shaft']),
			event.recipes.createDeploying(transitional, [transitional, 'create:precision_mechanism']),
			event.recipes.createDeploying(transitional, [transitional, 'create:shaft'])
		]).loops(3).transitionalItem('create:brass_casing')
		//Sequenced Gearshift
		event.recipes.createSequencedAssembly(['create:sequenced_gearshift',
		], 'create:brass_casing', [
			event.recipes.createDeploying(transitional, [transitional, 'minecraft:clock']),
			event.recipes.createDeploying(transitional, [transitional, 'create:cogwheel']),
			event.recipes.createDeploying(transitional, [transitional, 'create:electron_tube'])
		]).loops(1).transitionalItem('create:brass_casing')
		}
	}
	
	
	{//Create: Stuff and Additions
		{//removals
		event.remove({id: 'create_sa:copper_propeler_recipe'})
		event.remove({id: 'create_sa:andesite_jetpack_recipe'})
		event.remove({id: 'create_sa:brass_jetpack_recipe'})
		event.remove({id: 'create_sa:copper_exoskeleton_recipe'})
		event.remove({id: 'create_sa:andesite_exoskeleton_recipe'})
		event.remove({id: 'create_sa:brass_exoskeleton_recipe'})
		event.remove({id: 'create_sa:portable_drill_recipe'})
		event.remove({output: 'create_sa:hydraulic_engine'})
		event.remove({output: 'create_sa:heat_engine'})
		event.remove({output: 'create_sa:steam_engine'})
 		}
 		{//ADDED
		//Portable Drill
		event.recipes.createMechanicalCrafting('create_sa:portable_drill', [
			'BB  ',
			'SFED',
			'SSS '
		], {
			D: 'create_sa:brass_drill_head',
			E: 'create_sa:steam_engine',
			S: 'create:sturdy_sheet',
			F: 'ars_elemental:lesser_earth_focus',
			B: 'create:brass_ingot'
		})
		
		//Engines
		let transitional = 'create:copper_sheet'
		event.recipes.createSequencedAssembly(['create_sa:hydraulic_engine',
		], 'create:copper_sheet', [
			event.recipes.createDeploying(transitional, [transitional, 'create:mechanical_pump']),
			event.recipes.createDeploying(transitional, [transitional, 'ars_elemental:lesser_water_focus']),
			event.recipes.createDeploying(transitional, [transitional, 'create_sa:small_filling_tank']),
			event.recipes.createDeploying(transitional, [transitional, 'create:water_wheel'])
		]).loops(1).transitionalItem('create:copper_sheet')

		transitional = 'createdeco:zinc_sheet'
		event.recipes.createSequencedAssembly(['create_sa:heat_engine',
		], 'createdeco:zinc_sheet', [
			event.recipes.createDeploying(transitional, [transitional, 'create:propeller']),
			event.recipes.createDeploying(transitional, [transitional, 'ars_elemental:lesser_fire_focus']),
			event.recipes.createDeploying(transitional, [transitional, 'create_sa:small_fueling_tank']),
			event.recipes.createDeploying(transitional, [transitional, 'create:blaze_burner'])
		]).loops(1).transitionalItem('createdeco:zinc_sheet')

		transitional = 'create:brass_sheet'
		event.recipes.createSequencedAssembly(['create_sa:steam_engine',
		], 'create:brass_sheet', [
			event.recipes.createDeploying(transitional, [transitional, '#create:pressurized_air_sources']),
			event.recipes.createDeploying(transitional, [transitional, 'ars_elemental:lesser_air_focus']),
			event.recipes.createDeploying(transitional, [transitional, 'create_sa:small_fueling_tank']),
			event.recipes.createDeploying(transitional, [transitional, 'create:steam_engine'])
		]).loops(1).transitionalItem('create:brass_sheet')
		
		//Jetpacks
		const jetpack_ingredients = [['copper', 'create:fluid_pipe', 'medium_filling_tank', 'create_sa:hydraulic_engine', 'copper'],
									['andesite', 'create:chute', 'medium_fueling_tank', 'create_sa:heat_engine', 'zinc'],
									['brass', 'create:smart_fluid_pipe', 'medium_fueling_tank', 'create_sa:steam_engine', 'brass'],]
		for (let i in jetpack_ingredients){
			event.recipes.createMechanicalCrafting(Item.of('create_sa:' + jetpack_ingredients[i][0] + '_jetpack_chestplate', '{Damage:0}'), [
				'PTP',
				'E E',
				' B '
			], {
				P: jetpack_ingredients[i][1],
				T: 'create_sa:' + jetpack_ingredients[i][2],
				E: jetpack_ingredients[i][3],
				B: 'ars_nouveau:mundane_belt'
			})
			event.recipes.createMechanicalCrafting(Item.of('create_sa:' + jetpack_ingredients[i][0] + '_exoskeleton_chestplate', '{Damage:0}'), [
				'E',
				'T',
				'B'
			], {
				T: Item.of('create_sa:' + jetpack_ingredients[i][4] + '_chestplate', '{Damage:0}'),
				E: jetpack_ingredients[i][3],
				B: 'ars_nouveau:mundane_belt'
			})
		}//end for loop
		}
	}

	{//TomsStorage
		{//REMOVED
			event.remove({id: "toms_storage:inventory_connector"})
			event.remove({id: "toms_storage:open_crate"})
			event.remove({id: "toms_storage:trim"})
			event.remove({id: "toms_storage:inventory_cable"})
			event.remove({id: "toms_storage:inventory_cable_connector"})
			event.remove({id: "toms_storage:inventory_cable_connector_filtered"})
			event.remove({id: "toms_storage:inventory_proxy"})
			event.remove({id: "toms_storage:inventory_hopper_basic"})
			event.remove({id: "toms_storage:level_emitter"})
			event.remove({id: "toms_storage:storage_terminal"})
			event.remove({id: "toms_storage:crafting_terminal"})
			event.remove({id: "toms_storage:wireless_terminal"})
			event.remove({id: "toms_storage:adv_wireless_terminal"})
			event.remove({id: "toms_storage:paint_kit"})
		}
		{//ADDED
			event.shaped('toms_storage:ts.inventory_connector', [
				'XDX',
				'CRC',
				'XDX'
			], {
				D: 'create:electron_tube',
				X: 'create:brass_casing',
				R: 'create:content_observer',
				C: 'minecraft:diamond'
			})
			event.shaped('toms_storage:ts.open_crate', [
				'XDX',
				'XCX',
				'X X'
			], {
				D: 'create:electron_tube',
				X: 'create:andesite_casing',
				C: '#forge:chests'
			})
			event.shaped('2x toms_storage:ts.trim', [
				'XRX',
				'RCR',
				'XRX'
			], {
				X: '#forge:storage_blocks/bronze',
				R: 'minecraft:stick',
				C: '#forge:chests'
			})
			event.recipes.createCutting('4x toms_storage:ts.inventory_cable', ['toms_storage:ts.trim'])
			event.shaped('toms_storage:ts.inventory_cable_connector', [
				'  X',
				'RCD',
				'  X'
			], {
				D: 'toms_storage:ts.inventory_connector',
				X: 'create:brass_casing',
				R: 'toms_storage:ts.inventory_cable',
				C: 'create:belt_connector'
			})
			event.shapeless('toms_storage:ts.inventory_cable_connector_filtered',
			[
				'toms_storage:ts.inventory_cable_connector',
				'create:filter'
			])
			event.shaped('toms_storage:ts.inventory_proxy', [
				'XRX',
				'RCR',
				'XRX'
			], {
				X: 'create:brass_casing',
				R: 'alloyed:bronze_sheet',
				C: 'minecraft:prismarine_crystals'
			})
			event.shaped('toms_storage:ts.inventory_hopper_basic', [
				'   ',
				'XRX',
				' C '
			], {
				X: 'create:brass_sheet',
				R: 'toms_storage:ts.inventory_cable',
				C: 'create:brass_funnel'
			})
			event.shaped('toms_storage:ts.level_emitter', [
				'   ',
				'XRX',
				' C '
			], {
				X: 'create:brass_sheet',
				R: 'toms_storage:ts.inventory_cable',
				C: 'create:stockpile_switch'
			})
			event.shaped('toms_storage:ts.storage_terminal', [
				'RNR',
				'DDD',
				'XCX'
			], {
				D: 'create:display_board',
				X: 'create:brass_casing',
				R: 'hexcasting:slate',
				C: 'create:content_observer',
				N: 'create:nixie_tube'
			})
			event.shaped('toms_storage:ts.crafting_terminal', [
				'NCN',
				'DED',
				'XXX'
			], {
				D: 'brass_geodes:geode_diamond',
				X: 'create:brass_casing',
				C: 'toms_storage:ts.storage_terminal',
				E: 'create:mechanical_crafter',
				N: 'create:nixie_tube'
			})
			event.shaped('toms_storage:ts.adv_wireless_terminal', [
				'XDX',
				'RCR',
				'XLX'
			], {
				D: 'create:electron_tube',
				X: 'alloyed:steel_bars',
				R: '#forge:phantasm_crystals',
				C: 'toms_storage:ts.crafting_terminal',
				L: 'create:linked_controller'
			})
			event.shaped('toms_storage:ts.paint_kit', [
				'DW',
				'SB'
			], {
				D: '#forge:dyes',
				W: 'create:iron_sheet',
				S: 'minecraft:iron_nugget',
				B: 'minecraft:water_bucket'
			})
		}
	}
	
	{//Enchantment Industry
		{//removals
		event.remove({id: 'create_enchantment_industry:mixing/hyper_experience'})
 		}
 		{//ADDED
		event.recipes.createMixing([Fluid.of('create_enchantment_industry:hyper_experience', 10)], [
							'minecraft:diamond', 'byg:subzero_crystal_shard', Fluid.of('create_enchantment_industry:experience', 100)]).superheated()
 		}
	}
	
	{//Misc
		{//removals
 			event.remove({id: 'labels:label_supplementaries'})
 			event.remove({id: 'chunkloaders:basic_chunk_loader'})
 			event.remove({id: 'chunkloaders:advanced_chunk_loader'})
 			event.remove({id: 'chunkloaders:ultimate_chunk_loader'})
 		}
 		{//ADDED
		//labels
		event.shaped('labels:label', [
			'PPP',
			'PIP',
			'PPP'
		], {
			P: 'minecraft:paper',
			I: '#forge:dyes/black'
		})
		//Chunk Loaders
		event.recipes.createMechanicalCrafting('chunkloaders:basic_chunk_loader', [
			' OEO ',
			'OESEO',
			' OEO ',
		], {
			E: 'minecraft:ender_eye',
			O: 'forbidden_arcanus:obsidian_ingot',
			S: 'forbidden_arcanus:stellarite_piece'
		})
		event.recipes.createMechanicalCrafting('chunkloaders:advanced_chunk_loader', [
			' GCG ',
			'GSBSG',
			' GSG ',
		], {
			C: 'chunkloaders:basic_chunk_loader',
			G: 'forbidden_arcanus:arcane_gold_ingot',
			B: 'create_sa:blazing_pickaxe',
			S: 'alloyed:steel_ingot'
		})
		event.recipes.createMechanicalCrafting('chunkloaders:ultimate_chunk_loader', [
			' GSG ',
			'GBCBG',
			' GSG ',
		], {
			C: 'chunkloaders:advanced_chunk_loader',
			G: 'byg:therium_shard',
			B: 'brass_geodes:geode_diamond',
			S: '#forge:phantasm_crystals'
		})
 		}
	}

	{//Forbidden and Arcanus
		{//removals
 			event.remove({id: 'forbidden_arcanus:mundabitur_dust'})
 			event.remove({id: 'forbidden_arcanus:arcane_gold_ingot'})
 			event.remove({id: 'forbidden_arcanus:obsidian_with_iron'})
 		}
 		{//ADDED
		//darkstone
		event.recipes.createFilling('forbidden_arcanus:darkstone', [
			'minecraft:blackstone',
			Fluid.of('create_enchantment_industry:ink', 250)])
		//Mundabitur
		event.recipes.createMixing('4x forbidden_arcanus:mundabitur_dust', 
			['forbidden_arcanus:arcane_crystal_dust', 'minecraft:redstone', 'minecraft:gunpowder', 'ars_nouveau:source_gem'
			]).heated()
		//Arcane Gold
		event.recipes.createMixing('forbidden_arcanus:arcane_gold_ingot', 
			['forbidden_arcanus:mundabitur_dust', 'minecraft:gold_ingot'
			]).heated()
		//Obsidian Iron
		event.recipes.createCompacting('forbidden_arcanus:obsidian_with_iron', 
			['minecraft:iron_block', 'minecraft:obsidian'])
 		}
	}
})

	{//ModName
		{//removals
 			
 		}
 		{//ADDED

 		}
	}

onEvent('item.tags', event => {
	event.get('forge:phantasm_crystals').add('phantasm:crystal_block')	
	event.get('forge:phantasm_crystals').add('phantasm:void_crystal_block')	
	for (let c in coral_colors){
		event.get('forge:' + coral_colors[c] + '_corals').add('minecraft:' + coral_colors[c] + '_coral')
		event.get('forge:' + coral_colors[c] + '_corals').add('minecraft:' + coral_colors[c] + '_coral_fan')
		event.get('forge:dead_' + coral_colors[c] + '_corals').add('minecraft:dead_' + coral_colors[c] + '_coral')
		event.get('forge:dead_' + coral_colors[c] + '_corals').add('minecraft:dead_' + coral_colors[c] + '_coral_fan')
	}//end loop
	event.get('forge:warped_corals').add('byg:warped_coral')
	event.get('forge:warped_corals').add('byg:warped_coral_fan')
})