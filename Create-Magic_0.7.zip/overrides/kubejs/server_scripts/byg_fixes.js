onEvent('recipes', event => {
	
	//using Create machines
	event.recipes.createSplashing(
	['byg:cracked_red_sand'], ['minecraft:red_sandstone'])
	
	event.recipes.createCrushing(
	 ['byg:end_sand'], ['minecraft:end_stone'])
	event.recipes.createCrushing(
	 ['byg:subzero_ash_block'], ['byg:subzero_crystal_shard'])
	 
	event.recipes.createMixing(
	 ['byg:cryptic_magma_block'], ['byg:cryptic_stone', 'minecraft:magma_block'])
	event.recipes.createMixing(
	 ['infernalexp:basaltic_magma'], ['minecraft:basalt', 'minecraft:magma_block'])
	event.recipes.createMixing(
	 ['byg:frost_magma'], ['byg:subzero_ash_block', 'minecraft:magma_block'])
	event.recipes.createMixing(
	 ['byg:cryptic_stone'], ['minecraft:blackstone', 'infernalexp:dullstone'])
	 
	event.recipes.createMixing(
	 ['byg:brimstone'], ['minecraft:blackstone', 'minecraft:netherrack'])
	
	//byg Sand
	let sand_fix = function(color_sand, dye){
		  event.remove({id: 'byg:'+color_sand})
		  event.remove({id: 'byg:'+color_sand+'stone'})

		  event.shaped('byg:'+color_sand, [
			'SSS',
			'SDS',
			'SSS'
		  ], {
			S: '#forge:sand',
			D: dye
		  })
		  event.shaped('byg:'+color_sand+'stone', [
			'SS',
			'SS'
		  ], {
			S: 'byg:'+color_sand
		  })
	}

	sand_fix('blue_sand', '#forge:dyes/blue')
	sand_fix('white_sand', '#forge:dyes/white')
	sand_fix('black_sand', '#forge:dyes/black')
	sand_fix('purple_sand', '#forge:dyes/purple')
	sand_fix('windswept_sand', '#forge:dyes/pink')
	
	//Windswept Sand
	event.smelting('byg:smooth_windswept_sandstone', 'byg:windswept_sandstone')
	const windswept_sand_blocks = ['windswept_sandstone_slab', 'windswept_sandstone_stairs', 'windswept_sandstone_wall', 'chiseled_windswept_sandstone', 'chiseled_windswept_sandstone_slab', 'chiseled_windswept_sandstone_stairs', 'chiseled_windswept_sandstone_wall', 'cut_windswept_sandstone', 'cut_windswept_sandstone_slab', 'cut_windswept_sandstone_stairs', 'cut_windswept_sandstone_wall', 'smooth_windswept_sandstone_slab', 'smooth_windswept_sandstone_stairs', 'smooth_windswept_sandstone_wall', 'windswept_sandstone_pillar']
	for (let i = 0; i < windswept_sand_blocks.length; i++){
		event.stonecutting('byg:'+windswept_sand_blocks[i], 'byg:smooth_windswept_sandstone')
	}
	//byg soft blocks
	event.shapeless(
	Item.of('byg:warped_soul_sand', 2), [ 
		'minecraft:warped_wart_block',
		'minecraft:soul_sand'
	])
	event.shapeless(
	Item.of('byg:warped_soul_soil', 2), [ 
		'minecraft:warped_wart_block',
		'minecraft:soul_soil'
	])
	event.shapeless(
	Item.of('byg:ether_soil', 2), [ 
		'minecraft:dirt',
		'minecraft:end_stone'
	])
	event.shapeless(
	Item.of('byg:lush_dirt'), [ 
		'minecraft:dirt',
		'byg:mud_block'
	])
	event.shapeless(
	Item.of('byg:peat'), [ 
		'byg:mud_block',
		'minecraft:charcoal'
	])
	event.shaped(
	Item.of('3x byg:subzero_ash'), 
		['AAA'], {
		A: 'byg:subzero_ash_block'}
	)
	
	{//Spouting
	event.recipes.createFilling('byg:black_ice', [
		'minecraft:packed_ice',
		Fluid.of('create_enchantment_industry:ink', 250)])
	}
	
})