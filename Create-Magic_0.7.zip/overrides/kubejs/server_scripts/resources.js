onEvent('recipes', event => {
	
	{//removals
	event.remove({id: 'create:crushing/tuff'})
	event.remove({id: 'alloyed:mixing/steel_ingot'})
	event.remove({id: 'infernalexp:smelting/soul_stone'})
	}
	
	{//Extruder generator
	event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:cobbled_deepslate'),[
		Fluid.of('minecraft:lava', 1000),
		Fluid.of('create_enchantment_industry:ink', 1000)
		]).withCatalyst('minecraft:obsidian')
	event.recipes.createMechanicalExtruderExtruding(Item.of('quark:limestone').withChance(0.3),[
		Fluid.of("minecraft:lava", 1000),
		Fluid.of("minecraft:water", 1000)
		]).withCatalyst('minecraft:iron_block')
	event.recipes.createMechanicalExtruderExtruding(Item.of('quark:jasper').withChance(0.3),[
		Fluid.of("minecraft:lava", 1000),
		Fluid.of("minecraft:water", 1000)
		]).withCatalyst('minecraft:iron_block')
	event.recipes.createMechanicalExtruderExtruding(Item.of('quark:shale').withChance(0.3),[
		Fluid.of("minecraft:lava", 1000),
		Fluid.of("minecraft:water", 1000)
		]).withCatalyst('minecraft:iron_block')
	event.recipes.createMechanicalExtruderExtruding(Item.of('quark:myalite').withChance(0.3),[
		Fluid.of("minecraft:lava", 1000),
		Fluid.of("create_confectionery:ruby_chocolate", 1000)
		]).withCatalyst('minecraft:end_stone')
	event.recipes.createMechanicalExtruderExtruding(Item.of('byg:cobbled_ether_stone').withChance(0.3),[
		Fluid.of("minecraft:lava", 1000),
		Fluid.of("create_confectionery:ruby_chocolate", 1000)
		]).withCatalyst('minecraft:end_stone')
	event.recipes.createMechanicalExtruderExtruding(Item.of('phantasm:raw_purpur').withChance(0.3),[
		Fluid.of("minecraft:lava", 1000),
		Fluid.of("create_confectionery:ruby_chocolate", 1000)
		]).withCatalyst('minecraft:end_stone')
	}
	
	{//Mixing
	event.recipes.createMixing(['quark:myalite_crystal'], 
		['quark:myalite', '#quark:corundum_clusters']).heated()
	event.recipes.createMixing(['quark:dusky_myalite'], 
		['quark:myalite', '#minecraft:coals']).heated()
	event.recipes.createMixing(['2x alloyed:steel_ingot'], 
		['3x createdeco:cast_iron_ingot', '5x kubejs:carbon_powder']).heated()
	}
	
	{//Haunting
	event.recipes.createHaunting(['infernalexp:soul_stone'], 
		['minecraft:soul_sand'])
	}
	
	{//Rock Crushing
	event.recipes.createCrushing('minecraft:tuff', [
		'minecraft:deepslate'])	
	event.recipes.createCrushing(['2x forbidden_arcanus:arcane_crystal',
		Item.of('2x forbidden_arcanus:arcane_crystal_dust').withChance(0.4)], [
		'#forbidden_arcanus:arcane_crystal_ores'])
	}
	
	{//Sawmill
	event.recipes.createCutting('2x kubejs:carbon_powder', [
		'#minecraft:coals'])
	}
	
	{//Spouting
	event.recipes.createFilling('minecraft:calcite', [
		'minecraft:bone_block',
		Fluid.of('minecraft:milk', 500)])
	event.recipes.createFilling('3x minecraft:lapis_lazuli', 
					['kubejs:crushed_sapphire', Fluid.of('create:potion', 200, '{Potion:"minecraft:swiftness"}')])
	event.recipes.createFilling('3x minecraft:redstone', 
					['kubejs:crushed_ruby', Fluid.of('create:potion', 200, '{Potion:"minecraft:strength"}')])
	event.recipes.createFilling('3x minecraft:glowstone_dust', 
					['kubejs:crushed_topaz', Fluid.of('create:potion', 200, '{Potion:"minecraft:night_vision"}')])
	}
	
	{//Brass Geodes and ore gen
	let brass_gem = 'brass_geodes:'
	const gem_types = ['topaz', 'sapphire', 'ruby', 'emerald', 'diamond']
	const ore_block_types = ['ochrum', 'asurine', 'crimsite', 'veridium']
	const chocolate_ore = ['create_confectionery:white_chocolate', 'create_confectionery:black_chocolate', 
							'create:chocolate', 'create_confectionery:caramel']
	for (let i in gem_types) {

		if (i == 3 || i == 4){//Minecraft gems
			brass_gem = 'minecraft:'
		}
		else{//brass_geodes gems
			event.recipes.createCrushing('kubejs:crushed_' + gem_types[i], ['brass_geodes:' + gem_types[i]])
			event.recipes.createCrushing('kubejs:base_ore_' + ore_block_types[i], ['brass_geodes:' + gem_types[i] + '_block'])
			event.recipes.createCrushing('kubejs:base_ore_' + ore_block_types[i], ['kubejs:magic_ore_' + ore_block_types[i]])
			//event.recipes.arsCrush('kubejs:magic_ore_' + ore_block_types[i], ['brass_geodes:geode_' + gem_types[i]])
			event.custom({
			"type": "ars_nouveau:crush",
			"input": {
				"item": 'brass_geodes:geode_' + gem_types[i]
			},
			"output": [
				{
				"item": 'kubejs:magic_ore_' + ore_block_types[i],
				"chance": 1.0,
				"count": 1
				}
			]
			})
		}
		if (i == 3){//emerald
			event.recipes.createCrushing('kubejs:base_ore_' + ore_block_types[i], ['minecraft:' + gem_types[i] + '_block'])
			event.recipes.createCrushing('kubejs:base_ore_' + ore_block_types[i], ['kubejs:magic_ore_' + ore_block_types[i]])
			event.custom({
			"type": "ars_nouveau:crush",
			"input": {
				"item": 'brass_geodes:geode_' + gem_types[i]
			},
			"output": [
				{
				"item": 'kubejs:magic_ore_' + ore_block_types[i],
				"chance": 1.0,
				"count": 1
				}
			]
			})
		}
		if (i <= 3){//making the ore blocks
			event.recipes.createSequencedAssembly(['create:' + ore_block_types[i]
				//salvage area
				], 
				'kubejs:base_ore_' + ore_block_types[i], [
				event.recipes.createCutting('kubejs:base_ore_' + ore_block_types[i], 
					['kubejs:base_ore_' + ore_block_types[i]]),
				event.recipes.createFilling('kubejs:base_ore_' + ore_block_types[i], 
					['kubejs:base_ore_' + ore_block_types[i], Fluid.of(chocolate_ore[i], 250)]),
				event.recipes.createPressing('kubejs:base_ore_' + ore_block_types[i], 
					['kubejs:base_ore_' + ore_block_types[i]])
				]).transitionalItem('kubejs:base_ore_' + ore_block_types[i]).loops(4)
		}
		event.shaped('brass_geodes:geode_' + gem_types[i], [
			'SS',
			'SS'
		], {
			S: brass_gem + gem_types[i]
		})
		
	}//End for loop
	}
})