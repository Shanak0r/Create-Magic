// priority: 0

//console.info('Hello, World! (You will only see this line once in console, during startup)')

function capitalizeFirstLetter(str) {
  return(str.charAt(0).toUpperCase() + str.slice(1));
}

onEvent('item.registry', event => {
	// Register new items here
	// event.create('example_item').displayName('Example Item')
	
	 event.create('crushed_topaz').displayName('Crushed Topaz')
	 event.create('crushed_sapphire').displayName('Crushed Sapphire')
	 event.create('crushed_ruby').displayName('Crushed Ruby')
	 event.create('carbon_powder').displayName('Carbon Powder')
})

onEvent('block.registry', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
	
	const ore_block_types = ['ochrum', 'asurine', 'crimsite', 'veridium']
	for (let b in ore_block_types){
		event.create('base_ore_' + ore_block_types[b])
			.material('stone')
			.hardness(1.0)
			.displayName('Basic ' + capitalizeFirstLetter(ore_block_types[b]) + ' ore')
			.tagBoth('forge:base_ore') 
		event.create('magic_ore_' + ore_block_types[b])
			.material('stone')
			.hardness(1.0)
			.displayName('Magic ' + capitalizeFirstLetter(ore_block_types[b]) + ' ore')
			.tagBoth('forge:base_ore') 
			.tagBoth('forge:magic_ore') 
	}//End for loop
})